export const OasysPassport =
  '37aacf1e6bf6793c892e42c3f7623a61d9ffcb4337010804cc3193c4d596cf5c';

export const Coinbase =
  'fd20dc426fb37566d803205b19bbc1d4096b248ac04548e3cfb6b3a38bd033aa';

export const FaceWallet =
  'b6d18ff342920bb492f810bb070a064d6031ec2c3d6fffecb6ca233c8a591e00';

export const featuredWalletIds = [OasysPassport, Coinbase, FaceWallet];
